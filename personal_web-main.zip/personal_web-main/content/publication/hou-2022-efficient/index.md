---
title: An efficient coarse-to-fine alignment framework@ ego4d natural language queries
  challenge 2022
authors:
- Zhijian Hou
- Wanjun Zhong
- Lei Ji
- Difei Gao
- Kun Yan
- Wing-Kwong Chan
- Chong-Wah Ngo
- Zheng Shou
- Nan Duan
date: '2022-01-01'
publishDate: '2024-02-22T07:54:55.446891Z'
publication_types:
- article-journal
publication: '*arXiv preprint arXiv:2211.08776*'
links:
- icon_pack: fab
  icon: github
  name: code
  url: lhttps://github.com/houzhijian/CONE
---
