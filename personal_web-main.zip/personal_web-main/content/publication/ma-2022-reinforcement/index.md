---
title: Reinforcement learning-based interactive video search
authors:
- Zhixin Ma
- Jiaxin Wu
- Zhijian Hou
- Chong-Wah Ngo
date: '2022-01-01'
publishDate: '2024-02-22T07:54:55.428672Z'
publication_types:
- paper-conference
publication: '*International Conference on Multimedia Modeling*'
---
