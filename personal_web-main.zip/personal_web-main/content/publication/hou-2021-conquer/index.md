---
title: 'CONQUER: Contextual query-aware ranking for video corpus moment retrieval'
authors:
- Zhijian Hou
- Chong-Wah Ngo
date: '2021-01-01'
publishDate: '2024-02-22T07:54:55.411855Z'
publication_types:
- paper-conference
publication: '*Proceedings of the 29th ACM International Conference on Multimedia*'
links:
- icon_pack: fab
  icon: github
  name: code
  url: lhttps://github.com/houzhijian/CONQUER
---
