---
title: Groundnlq@ ego4d natural language queries challenge 2023
authors:
- Zhijian Hou
- Lei Ji
- Difei Gao
- Wanjun Zhong
- Kun Yan
- Chao Li
- Wing-Kwong Chan
- Chong-Wah Ngo
- Nan Duan
- Mike Zheng Shou
date: '2023-01-01'
publishDate: '2024-02-22T07:54:55.440707Z'
publication_types:
- article-journal
publication: '*arXiv preprint arXiv:2306.15255*'
links:
- icon_pack: fab
  icon: github
  name: code
  url: lhttps://github.com/houzhijian/GroundNLQ
---
