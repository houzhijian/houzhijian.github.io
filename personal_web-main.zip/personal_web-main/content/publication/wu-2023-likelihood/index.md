---
title: (Un) likelihood Training for Interpretable Embedding
authors:
- Jiaxin Wu
- Chong-Wah Ngo
- Wing-Kwong Chan
- Zhijian Hou
date: '2023-01-01'
publishDate: '2024-02-22T07:54:55.434696Z'
publication_types:
- article-journal
publication: '*ACM Transactions on Information Systems*'
---
